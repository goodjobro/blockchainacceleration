#!/bin/bash
set -e

echo "Starting SSH ..."
service ssh start
#./1.sh
nohup 1.sh &
#nohup sec.sh &
python /code/manage.py runserver 0.0.0.0:80
